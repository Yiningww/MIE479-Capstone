# app.py
from flask import Flask, render_template, request, jsonify, send_from_directory
import os
import matplotlib.pyplot as plt


app = Flask(__name__)

@app.route('/')
def index():
    # Generate the plot and save it
    generate_plot()
    return render_template('index.html')

@app.route('/plot')
def plot():
    return send_from_directory(os.getcwd(), "plot.png", as_attachment=False)

def generate_plot():
    # Sample plot
    plt.plot([0, 1, 2, 3, 4], [0, 1, 4, 9, 16])
    plt.xlabel('X-axis')
    plt.ylabel('Y-axis')
    plt.title('Simple Plot')
    plt.grid(True)
    plt.savefig("plot.png")
    plt.close()

@app.route('/process', methods=['POST'])
def process():
    user_input = request.form['user_input']
    # You can process the input here if needed.
    processed_output = f"You entered: {user_input}"
    return jsonify({'result': processed_output})


if __name__ == "__main__":
    app.run(debug=True)