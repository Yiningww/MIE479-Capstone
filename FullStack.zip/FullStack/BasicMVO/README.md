## Background -- Monday Sept. 22 2023

The code will not run in its current state. Try and figure it out by following the steps in the powerpoint presentation. 
