COLLECTION = 'stocks'           # MongoDB collection
API = 'qY6NzJTzXwLqfRxHzYrv'    # Quandl API key
TABLE = 'WIKI/'                 # Quandl table
COLLAPSE = 'monthly'            # Quandl data aggregation value
