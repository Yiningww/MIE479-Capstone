from flask import Blueprint, request, session, redirect, url_for, render_template

from models.users.user import User
import models.users.errors as UserErrors
import models.users.decorators as user_decorators
from common.database import Database
from models.portfolios.portfolio import Portfolio

from matplotlib.backends.backend_agg import FigureCanvasAgg as FigureCanvas
from io import BytesIO
import urllib
import base64


portfolio_blueprint = Blueprint('portfolios', __name__)

@portfolio_blueprint.route('/portfolio/<string:portfolio_id>')
@user_decorators.requires_login
def get_portfolio_page(portfolio_id):   # Renders unique portfolio page
    port = Portfolio.get_by_id(portfolio_id)
    
    fig_portfolio = port.plotportfolio()   # plot portfolio piechart
    fig_mvo = port.plotwealth()            # plot wealth evolution

    # Encoding fig_portfolio to base64
    img_portfolio = BytesIO()
    fig_portfolio.savefig(img_portfolio)
    img_portfolio.seek(0)
    plot_data_portfolio = base64.b64encode(img_portfolio.read()).decode()

    # Encoding fig_mvo to base64
    img_mvo = BytesIO()
    fig_mvo.savefig(img_mvo)
    img_mvo.seek(0)
    plot_data_mvo = base64.b64encode(img_mvo.read()).decode()

    return render_template('/portfolios/portfolio.jinja2', portfolio=port, plot_url_portfolio=plot_data_portfolio, plot_url_mvo=plot_data_mvo)

@portfolio_blueprint.route('/edit/<string:portfolio_id>', methods=['GET','POST'])
@user_decorators.requires_login
def change_risk(portfolio_id):         # Views form to change portfolio's associated risk aversion parameter
    port = Portfolio.get_by_id(portfolio_id)
    if request.method == "POST":
        risk_appetite = request.form['risk_appetite']
        port.risk_appetite = risk_appetite

        if risk_appetite == 'OLS + MVO':
            fig_portfolio = port.plotportfolio(testperiod=1, estimator='OLS', optimizer='MVO')   # plot portfolio piechart
            fig_mvo = port.plotwealth(testperiod=1, estimator='OLS', optimizer='MVO')            # plot wealth evolution

        if risk_appetite == 'OLS + Sharpe':
            fig_portfolio = port.plotportfolio(testperiod=1, estimator='OLS', optimizer='SharpeRatio')   # plot portfolio piechart
            fig_mvo = port.plotwealth(testperiod=1, estimator='OLS', optimizer='SharpeRatio')            # plot wealth evolution
        
        if risk_appetite == 'Ridge + MVOBox':
            fig_portfolio = port.plotportfolio(testperiod=1, estimator='Ridge', optimizer='MVOBox')   # plot portfolio piechart
            fig_mvo = port.plotwealth(testperiod=1, estimator='Ridge', optimizer='MVOBox')            # plot wealth evolution

        if risk_appetite == 'LSTM + RiskParity':
            fig_portfolio = port.plotportfolio(testperiod=1, estimator='LSTM', optimizer='RiskParity')   # plot portfolio piechart
            fig_mvo = port.plotwealth(testperiod=1, estimator='LSTM', optimizer='RiskParity')            # plot wealth evolution
        
        if risk_appetite == 'VAR + Sharpe':
            fig_portfolio = port.plotportfolio(testperiod=1, estimator='VAR', optimizer='SharpeRatio')   # plot portfolio piechart
            fig_mvo = port.plotwealth(testperiod=1, estimator='VAR', optimizer='SharpeRatio')            # plot wealth evolution


        # Encoding fig_portfolio to base64
        img_portfolio = BytesIO()
        fig_portfolio.savefig(img_portfolio)
        img_portfolio.seek(0)
        plot_data_portfolio = base64.b64encode(img_portfolio.read()).decode()

        # Encoding fig_mvo to base64
        img_mvo = BytesIO()
        fig_mvo.savefig(img_mvo)
        img_mvo.seek(0)
        plot_data_mvo = base64.b64encode(img_mvo.read()).decode()

        return render_template('/portfolios/portfolio.jinja2', portfolio=port, plot_url_portfolio=plot_data_portfolio, plot_url_mvo=plot_data_mvo)

        # port.save_to_mongo()
        # fig = port.runMVO()
        # canvas = FigureCanvas(fig)
        # img = BytesIO()
        # fig.savefig(img)
        # img.seek(0)
        # plot_data = base64.b64encode(img.read()).decode()
        # return render_template('/portfolios/optimal_portfolio.jinja2', portfolio = port, plot_url=plot_data)

    return render_template('/portfolios/edit_portfolio.jinja2',portfolio = port)

@portfolio_blueprint.route('/new', methods=['GET','POST'])
@user_decorators.requires_login
def create_portfolio():            # Views form to create portfolio associated with active/ loggedin user
    if request.method == "POST":
        risk_appetite = request.form['risk_appetite']
        port = Portfolio(session['email'], risk_appetite= risk_appetite)
        port.save_to_mongo()
        fig = port.runMVO()
        canvas = FigureCanvas(fig)
        img = BytesIO()
        fig.savefig(img)
        img.seek(0)
        plot_data = base64.b64encode(img.read()).decode()
        return render_template('/portfolios/optimal_portfolio.jinja2', portfolio=port, plot_url=plot_data)

    return render_template('/portfolios/new_portfolio.jinja2')
