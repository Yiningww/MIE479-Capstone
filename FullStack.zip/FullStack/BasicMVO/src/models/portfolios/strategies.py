import yfinance as yf
import pandas as pd
import numpy as np
import cvxpy as cp
from scipy.stats import norm
from scipy.stats import gmean
import matplotlib.pyplot as plt
import time
import math
from models.portfolios.estimators import OLS, LASSO, Ridge
from models.portfolios.optimizers import MVO, Risk_Parity, Sharpe, Sharpe_Box, robustMVO_box

# this file will produce portfolios as outputs from data - the strategies can be implemented as classes or functions
# if the strategies have parameters then it probably makes sense to define them as a class

# this file will produce portfolios as outputs from data - the strategies can be implemented as classes or functions
# if the strategies have parameters then it probably makes sense to define them as a class

def chatgpt_weight():
    #x = [0.08, 0.08, 0.07, 0.07, 0.06, 0.06, 0.07, 0.06, 0.07, 0.08, 0.06, 0.06, 0.06, 0.07, 0.06]
    x = [0.07, 0.07, 0.07, 0.07, 0.07, 0.07, 0.07, 0.07, 0.07, 0.07, 0.07, 0.07, 0.07, 0.07, 0.07]
    for ele in x:
      ele = ele/sum(x)
    return x
    #AAPL	AMZN	GOOG	GOOGL	HD	INTC	JNJ	JPM	MA	MSFT	PG	T	UNH	V	VZ

def equal_weight(periodReturns):
    """
    computes the equal weight vector as the portfolio
    :param periodReturns:
    :return:x
    """
    T, n = periodReturns.shape
    x = (1 / n) * np.ones([n])
    return x

class HistoricalMeanVarianceOptimization:
    """
    uses historical returns to estimate the covariance matrix and expected return
    """

    def __init__(self, NumObs=36):
        self.NumObs = NumObs  # number of observations to use

    def execute_strategy(self, periodReturns, factorReturns=None):
        """
        executes the portfolio allocation strategy based on the parameters in the __init__

        :param periodReturns:
        :param factorReturns:
        :return: x
        """
        factorReturns = None  # we are not using the factor returns
        returns = periodReturns.iloc[(-1) * self.NumObs:, :]
        #print(len(returns))
        mu = np.expand_dims(returns.mean(axis=0).values, axis=1)
        Q = returns.cov().values
        x = MVO(mu, Q)

        return x

class OLS_MVO:
    """
    uses historical returns to estimate the covariance matrix and expected return
    """

    def __init__(self, NumObs=36):
        self.NumObs = NumObs  # number of observations to use

    def execute_strategy(self, periodReturns, factorReturns):
        """
        executes the portfolio allocation strategy based on the parameters in the __init__

        :param factorReturns:
        :param periodReturns:
        :return:x
        """
        T, n = periodReturns.shape
        # get the last T observations
        returns = periodReturns.iloc[(-1) * self.NumObs:, :]
        factRet = factorReturns.iloc[(-1) * self.NumObs:, :]
        mu, Q = OLS(returns, factRet)
        x = MVO (mu, Q)
        return x

class LASSO_MVO:
    def __init__(self, NumObs=36):
        self.NumObs = NumObs  # number of observations to use

    def execute_strategy(self, periodReturns, factorReturns):
        T, n = periodReturns.shape
        returns = periodReturns.iloc[(-1) * self.NumObs:, :]
        factRet = factorReturns.iloc[(-1) * self.NumObs:, :]
        mu, Q = LASSO(returns, factRet, 100)
        x = MVO (mu, Q)
        return x

class Ridge_MVO:
    def __init__(self, NumObs=36):
        self.NumObs = NumObs  # number of observations to use

    def execute_strategy(self, periodReturns, factorReturns):
        T, n = periodReturns.shape
        returns = periodReturns.iloc[(-1) * self.NumObs:, :]
        factRet = factorReturns.iloc[(-1) * self.NumObs:, :]
        mu, Q = Ridge(returns, factRet, 10)
        x = MVO (mu, Q)
        return x

class OLS_RP:
    def __init__(self, NumObs=36):
        self.NumObs = NumObs  # number of observations to use

    def execute_strategy(self, periodReturns, factorReturns):
        T, n = periodReturns.shape
        returns = periodReturns.iloc[(-1) * self.NumObs:, :]
        factRet = factorReturns.iloc[(-1) * self.NumObs:, :]
        mu, Q = OLS(returns, factRet)
        x = Risk_Parity(Q, 0.005)
        return x

class LASSO_RP:
    def __init__(self, NumObs=36):
        self.NumObs = NumObs  # number of observations to use

    def execute_strategy(self, periodReturns, factorReturns):
        T, n = periodReturns.shape
        returns = periodReturns.iloc[(-1) * self.NumObs:, :]
        factRet = factorReturns.iloc[(-1) * self.NumObs:, :]
        mu, Q = LASSO(returns, factRet,10000)
        x = Risk_Parity(Q, 0.00001)
        return x

class Ridge_RP:
    def __init__(self, NumObs=36):
        self.NumObs = NumObs  # number of observations to use

    def execute_strategy(self, periodReturns, factorReturns):
        T, n = periodReturns.shape
        returns = periodReturns.iloc[(-1) * self.NumObs:, :]
        factRet = factorReturns.iloc[(-1) * self.NumObs:, :]
        mu, Q = Ridge(returns, factRet,10000)
        x = Risk_Parity(Q, c=0.00001)
        return x

class OLS_SR:
    def __init__(self, NumObs=36):
        self.NumObs = NumObs  # number of observations to use

    def execute_strategy(self, periodReturns, factorReturns):
        T, n = periodReturns.shape
        returns = periodReturns.iloc[(-1) * self.NumObs:, :]
        factRet = factorReturns.iloc[(-1) * self.NumObs:, :]
        mu, Q = OLS(returns, factRet)
        x = Sharpe(mu, Q)
        return x

class LASSO_SR:
    def __init__(self, NumObs=36):
        self.NumObs = NumObs  # number of observations to use

    def execute_strategy(self, periodReturns, factorReturns):
        T, n = periodReturns.shape
        returns = periodReturns.iloc[(-1) * self.NumObs:, :]
        factRet = factorReturns.iloc[(-1) * self.NumObs:, :]
        mu, Q = LASSO(returns, factRet,100)
        x = Sharpe(mu, Q)
        return x

class Ridge_SR:
    def __init__(self, NumObs=36):
        self.NumObs = NumObs  # number of observations to use

    def execute_strategy(self, periodReturns, factorReturns):
        T, n = periodReturns.shape
        returns = periodReturns.iloc[(-1) * self.NumObs:, :]
        factRet = factorReturns.iloc[(-1) * self.NumObs:, :]
        mu, Q = Ridge(returns, factRet,0.0000001)
        x = Sharpe(mu, Q)
        return x

class OLS_MVOBox:
    def __init__(self, NumObs=36):
        self.NumObs = NumObs  # number of observations to use

    def execute_strategy(self, periodReturns, factorReturns):
        T, n = periodReturns.shape
        returns = periodReturns.iloc[(-1) * self.NumObs:, :]
        factRet = factorReturns.iloc[(-1) * self.NumObs:, :]
        mu, Q = OLS(returns, factRet)
        x = robustMVO_box(mu,Q, lamda=0.01, alpha = 0.25, T = 1000)
        return x

class LASSO_MVOBox:
    def __init__(self, NumObs=36):
        self.NumObs = NumObs  # number of observations to use

    def execute_strategy(self, periodReturns, factorReturns):
        T, n = periodReturns.shape
        returns = periodReturns.iloc[(-1) * self.NumObs:, :]
        factRet = factorReturns.iloc[(-1) * self.NumObs:, :]
        mu, Q = LASSO(returns, factRet,0.1)
        x = robustMVO_box(mu,Q, lamda=0.01, alpha = 0.25, T = 10000)
        return x

class Ridge_MVOBox:
    def __init__(self, NumObs=36):
        self.NumObs = NumObs  # number of observations to use

    def execute_strategy(self, periodReturns, factorReturns):
        T, n = periodReturns.shape
        returns = periodReturns.iloc[(-1) * self.NumObs:, :]
        factRet = factorReturns.iloc[(-1) * self.NumObs:, :]
        mu, Q = Ridge(returns, factRet,0.1)
        x = robustMVO_box(mu,Q, lamda=0.01, alpha = 0.25, T = 10000)
        return x

class OLS_SharpeBox:
    def __init__(self, NumObs=36):
        self.NumObs = NumObs  # number of observations to use

    def execute_strategy(self, periodReturns, factorReturns):
        T, n = periodReturns.shape
        returns = periodReturns.iloc[(-1) * self.NumObs:, :]
        factRet = factorReturns.iloc[(-1) * self.NumObs:, :]
        mu, Q = OLS(returns, factRet)
        x = Sharpe_Box(mu, Q, alpha=0.001, T= 1000000)
        return x

class LASSO_SharpeBox:
    def __init__(self, NumObs=36):
        self.NumObs = NumObs  # number of observations to use

    def execute_strategy(self, periodReturns, factorReturns):
        T, n = periodReturns.shape
        returns = periodReturns.iloc[(-1) * self.NumObs:, :]
        factRet = factorReturns.iloc[(-1) * self.NumObs:, :]
        mu, Q = LASSO(returns, factRet,0.00001)
        x = Sharpe_Box(mu, Q, alpha=0.90, T= 1000000)
        return x

class Ridge_SharpeBox:
    def __init__(self, NumObs=36):
        self.NumObs = NumObs  # number of observations to use

    def execute_strategy(self, periodReturns, factorReturns):
        T, n = periodReturns.shape
        returns = periodReturns.iloc[(-1) * self.NumObs:, :]
        factRet = factorReturns.iloc[(-1) * self.NumObs:, :]
        mu, Q = Ridge(returns, factRet,10000)
        x = Sharpe_Box(mu, Q, alpha=0.90, T= 1000000)
        return x

class LSTM_RP:
    def __init__(self, NumObs=36):
        self.NumObs = NumObs  # number of observations to use

    def execute_strategy(self, periodReturns, factorReturns):
        T, n = periodReturns.shape
        returns = periodReturns.iloc[(-1) * self.NumObs:, :]
        factRet = factorReturns.iloc[(-1) * self.NumObs:, :]
        mu = pd.read_csv('/Users/linlin/OneDrive - University of Toronto/大学课程/大四上/MIE479/FullStack/BasicMVO/src/models/portfolios/LSTM_GPT_mu_1.csv', header=None)
        Q = pd.read_csv('/Users/linlin/OneDrive - University of Toronto/大学课程/大四上/MIE479/FullStack/BasicMVO/src/models/portfolios/LSTM_GPT_Q_1.csv', header=None)
        mu_np = np.array(mu)
        Q_np = np.array(Q)
        x = Risk_Parity(Q_np, c=0.00001)
        print(Q)
        return x

class VAR_SR:
    def __init__(self, NumObs=36):
        self.NumObs = NumObs  # number of observations to use

    def execute_strategy(self, periodReturns, factorReturns):
        T, n = periodReturns.shape
        returns = periodReturns.iloc[(-1) * self.NumObs:, :]
        factRet = factorReturns.iloc[(-1) * self.NumObs:, :]
        mu = pd.read_csv('/Users/linlin/OneDrive - University of Toronto/大学课程/大四上/MIE479/FullStack/BasicMVO/src/models/portfolios/VAR_GPT_mu_1.csv', header=None)
        Q = pd.read_csv('/Users/linlin/OneDrive - University of Toronto/大学课程/大四上/MIE479/FullStack/BasicMVO/src/models/portfolios/VAR_GPT_Q_1.csv', header=None)
        mu_np = np.array(mu)
        Q_np = np.array(Q)
        x = Sharpe(mu_np, Q_np)
        return x
    

def project_function(estimator, optimizer, periodReturns, periodFactRet):
    """
    Please feel free to modify this function as desired
    :param periodReturns:
    :param periodFactRet:
    :return: the allocation as a vector
    """
    if estimator == 'OLS' and optimizer == 'MVO': Strategy = OLS_MVO()
    if estimator == 'LASSO' and optimizer == 'MVO': Strategy = LASSO_MVO()
    if estimator == 'Ridge' and optimizer == 'MVO': Strategy = Ridge_MVO()

    if estimator == 'OLS' and optimizer == 'RiskParity': Strategy = OLS_RP()
    if estimator == 'LASSO' and optimizer == 'RiskParity': Strategy = LASSO_RP()
    if estimator == 'Ridge' and optimizer == 'RiskParity': Strategy = Ridge_RP()

    if estimator == 'OLS' and optimizer == 'SharpeRatio': Strategy = OLS_SR()
    if estimator == 'LASSO' and optimizer == 'SharpeRatio': Strategy = LASSO_SR()
    if estimator == 'Ridge' and optimizer == 'SharpeRatio': Strategy = Ridge_SR()

    if estimator == 'OLS' and optimizer == 'MVOBox': Strategy = OLS_MVOBox()
    if estimator == 'LASSO' and optimizer == 'MVOBox': Strategy = LASSO_MVOBox()
    if estimator == 'Ridge' and optimizer == 'MVOBox': Strategy = Ridge_MVOBox()

    if estimator == 'OLS' and optimizer == 'SharpeBox': Strategy = OLS_SharpeBox()
    if estimator == 'LASSO' and optimizer == 'SharpeBox': Strategy = LASSO_SharpeBox()
    if estimator == 'Ridge' and optimizer == 'SharpeBox': Strategy = Ridge_SharpeBox()

    if estimator == 'LSTM' and optimizer == 'RiskParity': Strategy = LSTM_RP()
    if estimator == 'VAR' and optimizer == 'SharpeRatio': Strategy = VAR_SR()

    if estimator == 'GPT' and optimizer == 'GPT': x = chatgpt_weight()

    x = Strategy.execute_strategy(periodReturns, periodFactRet)
    return x