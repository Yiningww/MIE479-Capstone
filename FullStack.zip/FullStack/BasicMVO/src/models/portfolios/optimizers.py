import yfinance as yf
import pandas as pd
import numpy as np
import cvxpy as cp
from scipy.stats import norm
from scipy.stats import gmean
import matplotlib.pyplot as plt
import time
import math
from scipy.optimize import minimize


def MVO(mu, Q):
    """
    #---------------------------------------------------------------------- Use this function to construct an example of a MVO portfolio.
    #
    # An example of an MVO implementation is given below. You can use this
    # version of MVO if you like, but feel free to modify this code as much
    # as you need to. You can also change the inputs and outputs to suit
    # your needs.

    # You may use quadprog, Gurobi, or any other optimizer you are familiar
    # with. Just be sure to include comments in your code.

    # *************** WRITE YOUR CODE HERE ***************
    #----------------------------------------------------------------------
    """

    # Find the total number of assets
    n = len(mu)

    # Set the target as the average expected return of all assets
    targetRet = np.mean(mu)

    # Disallow short sales
    lb = np.zeros(n)

    # Add the expected return constraint
    A = -1 * mu.T
    b = -1 * targetRet

    # constrain weights to sum to 1
    Aeq = np.ones([1, n])
    beq = 1

    # Define and solve using CVXPY
    x = cp.Variable(n)
    prob = cp.Problem(cp.Minimize((1 / 2) * cp.quad_form(x, Q)),
                      [A @ x <= b,
                       Aeq @ x == beq,
                       x >= lb])
    prob.solve(verbose=False)
    return x.value

def Risk_Parity(Q, c):
    # Number of assets
    n = Q.shape[0]

    # Initial solution
    y0 = np.ones(n) / n

    # Objective function
    def objective(y):
        return 0.5 * y.T @ Q @ y - c * np.sum(np.log(y))

    # Constraints (no short sales)
    bounds = [(0, None) for _ in range(n)]

    # Non-linear constraints (if any, currently empty)
    def nlcon(y):
        return []

    # Optimization
    result = minimize(objective, y0, method='SLSQP', bounds=bounds, constraints={'type': 'eq', 'fun': nlcon}, tol=1e-9)

    # Recover optimal asset weights
    y = result.x
    x = y / np.sum(y)
    return x

def Sharpe(mu, Q):
    # Find the total number of assets
    n = len(mu)

    # Set the target as the average expected return of all assets
    targetRet = np.mean(mu)

    # Disallow short sales
    lb = np.zeros(n)

    Aeq = 1 * mu.T
    beq = 1

    A = np.ones([1, n])
    b = 0

    # Define and solve using CVXPY
    x = cp.Variable(n)

    prob = cp.Problem(cp.Minimize(cp.quad_form(x, Q)), [Aeq @ x == beq, A @ x >= b, x >= lb])

    prob.solve()
    #print(x.value)
    return x.value / np.sum(x.value)

def Sharpe_Box(mu, Q, T, alpha):
    # Number of assets n
    n = mu.shape[0]

    # Calculate theta, epsilon, and delta
    epsilon = norm.ppf(1 - (1 - alpha)/2)
    theta = np.sqrt((1/T) * np.diag(Q))
    delta = epsilon * theta

    # Define the optimization variable
    x = cp.Variable(n)

    # Define the objective function
    objective = cp.Minimize(cp.quad_form(x, Q))

    Aeq = np.ones([1, n])


    # Define the inequality constraint (linear)
    #constraints = [cp.sum(x) == 1, mu.T @ x - delta @ cp.abs(x) <= 0, x >= 0]
    constraints = [Aeq @ x == 1, mu.T @ x - delta @ cp.abs(x) <= 0, x >= 0]

    # Define the optimization problem
    prob = cp.Problem(objective, constraints)

    # Solve the problem
    prob.solve()

    # Retrieve the optimal portfolio weights
    return x.value / np.sum(x.value)

def robustMVO_box(mu, Q, lamda, alpha, T):
    # Number of assets
    n = len(mu)

    # Set the target as the average expected return of all assets
    targetRet = np.mean(mu)

    # Number of observations
    N = T

    # Calculate size of the box uncertainty set
    epsilon = norm.ppf(1 - (1 - alpha)/2)
    theta = np.sqrt((1/N) * np.diag(Q))
    delta = epsilon * theta

    # Define the optimization variable
    x = cp.Variable(n)
    # Define the objective function
    # print("lamda shape:", lamda)
    # print("cp.quad_form(x,Q) shape:", cp.quad_form(x, Q))
    # print("mu @ x shape:", mu.T @ x)
    # print(cp.norm(delta @ cp.abs(x), 'inf'))
    #print(mu)
    objective = cp.Minimize(lamda * cp.quad_form(x, Q) - (mu.T @ x - cp.norm(delta @ cp.abs(x), 'inf')))

    # Define the equality constraint matrices
    A_eq = np.ones((1, n))
    #print(A_eq.shape)
    b_eq = 1

    # Define the inequality constraint (short sales disallowed)
    constraints = [x >= 0]

    # Define the optimization problem
    prob = cp.Problem(objective, [A_eq @ x == b_eq] + constraints)

    # Solve the problem
    prob.solve()


    # Retrieve the optimal portfolio weights
    x = x.value / np.sum(x.value)

    return x

