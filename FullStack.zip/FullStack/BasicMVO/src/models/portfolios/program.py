
import numpy as np
import pandas as pd
import matplotlib
import matplotlib.pyplot as plt
matplotlib.use('Agg')
plt.style.use('ggplot')

from models.portfolios.strategies import project_function


def executeprogram(testperiod, estimator, optimizer):
    # Load Data
    adjClose = pd.read_csv("/Users/linlin/OneDrive - University of Toronto/大学课程/大四上/MIE479/FullStack/BasicMVO/src/models/portfolios/MIE479_AssetPrices.csv", index_col=0)
    factorRet = pd.read_csv("/Users/linlin/OneDrive - University of Toronto/大学课程/大四上/MIE479/FullStack/BasicMVO/src/models/portfolios/MIE479_FactorReturns.csv", index_col=0)
    adjClose.index = pd.to_datetime(adjClose.index)
    factorRet.index = pd.to_datetime(factorRet.index)

    # Initial budget to invest ($100,000)
    initialVal = 100000

    # Length of investment period (in months)
    investPeriod = 1

    # divide the factor returns by  100
    factorRet = factorRet/100

    #rf and factor returns
    riskFree = factorRet['RF']
    factorRet = factorRet.loc[:,factorRet.columns != 'RF'];

    #Identify the tickers and the dates
    tickers = adjClose.columns
    dates   = factorRet.index

    # Calculate the stocks weekly excess returns
    # pct change and drop the first null observation
    returns = adjClose.pct_change(1).iloc[1:, :]
    returns = returns  - np.diag(riskFree.values) @ np.ones_like(returns.values)
    # Align the price table to the asset and factor returns tables by discarding the first observation.
    adjClose = adjClose.iloc[1:,:]

    assert adjClose.index[0] == returns.index[0]
    assert adjClose.index[0] == factorRet.index[0]

    # Start of out-of-sample test period (User define here)
    if testperiod == 1: testStart = returns.index[0] + pd.offsets.DateOffset(years=5) + pd.offsets.DateOffset(months = 1) #outsample1
    if testperiod == 2:testStart = returns.index[0] + pd.offsets.DateOffset(years=5) + pd.offsets.DateOffset(months = 19) #outsample2
    if testperiod == 3: testStart = returns.index[0] + pd.offsets.DateOffset(years=5) + pd.offsets.DateOffset(months = 21) #outsample3

    #End of the first investment period
    testEnd = returns.index[-1]

    # End of calibration period (training/ in-sample)
    calEnd = returns.index[0] + pd.offsets.DateOffset(years=5)

    # Total number of investment periods
    NoPeriods = 1

    # Number of assets
    n  = len(tickers)

    # Preallocate space for the portfolio weights (x0 will be used to calculate the turnover rate)
    x  = np.zeros([n, NoPeriods])

    # Preallocate space for the portfolio per period value and turnover
    currentVal = np.zeros([NoPeriods, 1])

    #Initiate counter for the number of observations per investment period
    toDay = 0

    # Empty list to measure the value of the portfolio over the period
    portfValue = []

    for t in range(NoPeriods):
        # Subset the returns and factor returns corresponding to the current calibration period.
        periodReturns = returns[returns.index <= calEnd]
        periodFactRet = factorRet[factorRet.index <= calEnd]

        #current_price_idx = (calEnd - pd.offsets.DateOffset(days=7) <= adjClose.index)&(adjClose.index <= calEnd)
        current_price_idx = (testStart - pd.offsets.DateOffset(days=7) <= adjClose.index)&(adjClose.index <= testStart) #outsample 2/3
        currentPrices = adjClose[current_price_idx]

        # Subset the prices corresponding to the current out-of-sample test period.
        periodPrices_idx = (testStart <= adjClose.index)&(adjClose.index <= testEnd)
        periodPrices = adjClose[periodPrices_idx]

        if t == 0:
            currentVal[0] = initialVal
        else:
            currentVal[t] = currentPrices @  NoShares.values.T
            #Store the current asset weights (before optimization takes place)
            #x0[:,t] = currentPrices.values*NoShares.values/currentVal[t]

        #----------------------------------------------------------------------
        # Portfolio optimization
        # You must write code your own algorithmic trading function
        #----------------------------------------------------------------------
        x[:,t] = project_function(estimator, optimizer, periodReturns, periodFactRet)

        # Number of shares your portfolio holds per stock
        NoShares = x[:,t]*currentVal[t]/currentPrices

        # Update counter for the number of observations per investment period
        fromDay = toDay
        toDay   = toDay + len(periodPrices)

        # Weekly portfolio value during the out-of-sample window
        portfValue.append(periodPrices @ NoShares.values.T)

        # Update your calibration and out-of-sample test periods
        testStart = testStart + pd.offsets.DateOffset(months=investPeriod)
        testEnd   = testStart + pd.offsets.DateOffset(months=investPeriod) - pd.offsets.DateOffset(days=1)
        calEnd    = testStart - pd.offsets.DateOffset(days=1)

    portfValue = pd.concat(portfValue, axis = 0)

    #--------------------------------------------------------------------------
    # 3.1 Calculate the portfolio average return, standard deviation, Sharpe ratio and average turnover.
    #-----------------------------------------------------------------------
    # Calculate the observed portfolio returns
    portfRets = portfValue.pct_change(1).iloc[1:,:]
    #print(portfRets)
    # Calculate the portfolio excess returns
    portfExRets = portfRets.subtract(riskFree[(riskFree.index >= portfRets.index[0])&(riskFree.index <= portfRets.index[-1])], axis = 0)
    #print(riskFree)
    # Calculate the portfolio Sharpe ratio
    GeoMean = np.prod(portfExRets +1) ** (1 / len(portfExRets))
    #SR = ((portfExRets + 1).apply(gmean, axis=0) - 1)/portfExRets.std()
    SR = (GeoMean -1)/portfExRets.std()

    #--------------------------------------------------------------------------
    # 3.2 Portfolio wealth evolution plot
    #--------------------------------------------------------------------------
    # Calculate the dates of the out-of-sample period

    fig = plt.figure(1)
    portfValue.plot(title = 'Portfolio wealth evolution',
                    ylabel = 'Total wealth',
                    figsize = (6, 3),
                    legend = False)

    #--------------------------------------------------------------------------
    # 3.3 Portfolio weights plot
    #--------------------------------------------------------------------------
    # Portfolio weights

    fig2 = plt.figure(2);

    x[x < 0] = 0
    weights = pd.DataFrame(x, index = tickers)
    weights.columns = [col + 1 for col in weights.columns]

    # Plotting a pie chart
    fig, ax = plt.subplots(figsize=(6, 6))
    colors = plt.cm.Paired(np.linspace(0, 1, len(tickers)))
    np.random.shuffle(colors)

    ax.pie(x[:,0], labels=tickers, autopct='%1.1f%%', startangle=90, colors=colors)
    ax.axis('equal')  # Equal aspect ratio ensures that the pie is drawn as a circle.

    # Add a title
    plt.title('Portfolio Weights')
    plt.savefig("/Users/linlin/OneDrive - University of Toronto/大学课程/大四上/MIE479/FullStack/BasicMVO/src/models/portfolios/weights.svg");

    # Show the plot
    # plt.show()
    return fig, fig2