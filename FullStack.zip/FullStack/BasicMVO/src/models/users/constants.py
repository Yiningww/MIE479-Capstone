COLLECTION = 'users'        # MongoDB collection
