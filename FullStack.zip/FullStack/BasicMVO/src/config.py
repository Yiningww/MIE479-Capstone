DEBUG = True
ADMINS = frozenset([
    "htmanis@gmail.com",
    "test@test.com"
])
